NAME='logsocket'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['logsocket_plugin']
