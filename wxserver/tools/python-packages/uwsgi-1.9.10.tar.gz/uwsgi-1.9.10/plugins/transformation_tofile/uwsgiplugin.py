NAME='transformation_tofile'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['tofile']
