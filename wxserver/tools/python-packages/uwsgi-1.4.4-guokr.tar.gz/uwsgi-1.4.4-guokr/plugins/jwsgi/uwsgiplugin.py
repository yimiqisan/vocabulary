import os,sys,platform

NAME='jwsgi'

# Snow Leopard
#JVM_INCPATH = "/Developer/SDKs/MacOSX10.6.sdk/System/Library/Frameworks/JavaVM.framework/Versions/1.6.0/Headers/"
#JVM_LIBPATH = "/Developer/SDKs/MacOSX10.6.sdk/System/Library/Frameworks/JavaVM.framework/Versions/1.6.0/Libraries/ -framework JavaVM"

# Ubuntu - openjdk6
#JVM_INCPATH = "/usr/lib/jvm/java-6-sun-1.6.0.15/include/ -I/usr/lib/jvm/java-6-sun-1.6.0.15/include/linux"
#JVM_LIBPATH = "/usr/lib/jvm/java-6-sun-1.6.0.15/jre/lib/i386/server/"

# Ubuntu - openjdk7
if platform.architecture()[0] == "64bit":
    if os.path.exists("/usr/lib/jvm/java-7-openjdk-amd64"):
        JVM_INCPATH = "/usr/lib/jvm/java-7-openjdk-amd64/include/ -I/usr/lib/jvm/java-7-openjdk-amd64/include/linux"
        JVM_LIBPATH = "/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/amd64/server/"
    if os.path.exists("/usr/lib/jvm/java-7-openjdk"):
        JVM_INCPATH = "/usr/lib/jvm/java-7-openjdk/include/ -I/usr/lib/jvm/java-7-openjdk/include/linux"
        JVM_LIBPATH = "/usr/lib/jvm/java-7-openjdk/jre/lib/amd64/server/"
else:
    if os.path.exists("/usr/lib/jvm/java-7-openjdk-i386"):
        JVM_INCPATH = "/usr/lib/jvm/java-7-openjdk-i386/include/ -I/usr/lib/jvm/java-7-openjdk-i386/include/linux"
        JVM_LIBPATH = "/usr/lib/jvm/java-7-openjdk-i386/jre/lib/i386/server/"
    if os.path.exists("/usr/lib/jvm/java-7-openjdk"):
        JVM_INCPATH = "/usr/lib/jvm/java-7-openjdk/include/ -I/usr/lib/jvm/java-7-openjdk/include/linux"
        JVM_LIBPATH = "/usr/lib/jvm/java-7-openjdk/jre/lib/i386/server/"

CFLAGS = ['-I' + JVM_INCPATH]
LDFLAGS = ['-L' + JVM_LIBPATH]
LIBS = ['-ljvm']
GCC_LIST = ['jwsgi_plugin']

if os.environ.has_key('LD_RUN_PATH'):
    os.environ['LD_RUN_PATH'] += ':' + JVM_LIBPATH
else:
    os.environ['LD_RUN_PATH'] = JVM_LIBPATH
