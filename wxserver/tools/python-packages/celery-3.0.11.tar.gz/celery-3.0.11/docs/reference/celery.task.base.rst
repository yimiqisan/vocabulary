===================================
 celery.task.base (Deprecated)
===================================

.. contents::
    :local:
.. currentmodule:: celery.task.base

.. automodule:: celery.task.base
    :members: BaseTask, PeriodicTask, TaskType
