========
Pyflakes
========

A simple program which checks Python source files for errors.

It is `available on PyPI <http://pypi.python.org/pypi/pyflakes>`_
and it supports all active versions of Python from 2.5 to 3.3.


Installation
------------

It can be installed with::

  $ pip install --upgrade pyflakes


.. image:: https://api.travis-ci.org/pyflakes/pyflakes.png
   :target: https://travis-ci.org/pyflakes/pyflakes
   :alt: Build status
