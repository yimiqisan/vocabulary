from distutils.core import setup

setup(name='flexmock',
      version='0.9.6',
      py_modules=['flexmock'],
      author='Herman Sheremetyev',
      author_email='herman@swebpage.com',
      url='http://has207.github.com/flexmock/',
      license='FreeBSD style license',
)
